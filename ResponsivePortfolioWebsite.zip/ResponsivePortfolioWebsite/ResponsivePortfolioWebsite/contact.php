<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json"); // Set response content type to JSON

// Database configuration
$servername = "localhost";
$username = "root1";
$password = "mAnik@2222";
$dbname = "contactDB";
$port = "3307";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die(json_encode(array("success" => false, "message" => "Connection failed: " . $conn->connect_error)));
}

// Check request method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debugging output
    error_log("Received POST request with data: " . print_r($_POST, true)); // Log the POST data for debugging
    
    // Get the POST data and sanitize inputs
    $name = isset($_POST['name']) ? htmlspecialchars($_POST['name']) : '';
    $email = isset($_POST['email']) ? filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) : '';
    $subject = isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : '';
    $message = isset($_POST['message']) ? htmlspecialchars($_POST['message']) : '';

    // Validate inputs
    if (empty($name) || empty($email) || empty($message)) {
        echo json_encode(array("success" => false, "message" => "Please fill in all required fields."));
        exit;
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $message);

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode(array("success" => true, "message" => "Message saved successfully"));
    } else {
        echo json_encode(array("success" => false, "message" => "Error: " . $stmt->error));
    }

    // Close the statement and connection
    $stmt->close();
}

$conn->close();
?>
